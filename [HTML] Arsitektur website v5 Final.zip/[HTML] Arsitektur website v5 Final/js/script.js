// $('.page-scroll').on('click', function(e){
//     //ambil isi href
//     var tujuan = $(this).attr('href');
//     //tangkap emen ybs
//     var elemenTujuan = $(tujuan);

//     //pindah scroll
//     $('body').animate({
//         scrollTop: elemenTujuan.offset().top - 50
//     }, 1250, 'easeInOutExpo');

//     e.preventDefault();

// });

$(window).on('load', function() {
    $('.effect-left').addClass('Eshow');
    $('.effect-right').addClass('Eshow');
});

$(window).scroll(function() {
    var wScroll = $(this).scrollTop();

    //global effect
    $('.global-effect .effect-1').css ({
        'transform' : 'translate(0px, '+ wScroll/4 +'%)'
    })


    $('.effect-1').css ({
        'transform' : 'translate(0px, '+ wScroll/4 +'%)'
    })

    //global img effect
    if (wScroll > $('.global-img-effect').offset().top - 700 ) {
        $('.global-img-effect .img-effect').each(function(test) {
            setTimeout(function() {
                $('.global-img-effect .img-effect').eq(test).addClass('show')
            }, 250 * (test + 1));
        });

        // tanpa efek muncul satu-satu
        //$('.global-img-effect .img-effect').addClass('show')
    }
});